package com.example.springtemplate.models;

import javax.persistence.*;

@Entity
@Table(name="jobs")
public class Job {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;
  private String title;
  private String companyName;
  private String level;
  private Integer companyId;


  public Integer getId() { return id; }
  public void setId(Integer id) { this.id = id; }
  public String getTitle() { return title; }
  public void setTitle(String title) { this.title = title; }
  public String getCompanyName() { return companyName; }
  public void setCompanyName(String companyName) { this.companyName = companyName; }
  public String getLevel() { return level; }
  public void setLevel(String level) { this.level = level; }
  public Integer getCompanyId() { return companyId; }
  public void setCompanyId(Integer companyId) { this.companyId = companyId; }

  public Job(String title, String companyName, String level, Integer companyId) {
    this.level = level;
    this.title = title;
    this.companyName = companyName;
    this.companyId = companyId;
  }

  public Job() {}
}
